// Land Helper BD Pro - Main World Controller (mutation.land.gov.bd)
// 100% Reliable Client-Side Rendering with Strict Server-Side Hit Metering

(function() {
    'use strict';
    if (window._lh_main_loaded) return;
    window._lh_main_loaded = true;

    // 0. License State & Hit Metering Bridge
    var _lh_k = '';
    var _lh_act = false;
    var _lh_fp = '';
    var _lh_badge_text = '';
    var _lh_is_busy = false;

    function readLocalLicense() {
        try {
            _lh_k = sessionStorage.getItem('__lh_k') || _lh_k || '';
            _lh_act = (sessionStorage.getItem('__lh_act') === '1') || _lh_act;
            _lh_fp = sessionStorage.getItem('__lh_fp') || _lh_fp || '';
        } catch(e) {}
    }
    readLocalLicense();

    window.addEventListener('message', function(e) {
        if (e.source !== window || !e.data) return;
        if (e.data.type === 'LH_SYNC_LICENSE_RES') {
            _lh_k = e.data.key || _lh_k;
            _lh_act = Boolean(e.data.isActive);
            _lh_fp = e.data.fp || _lh_fp;
            readLocalLicense();
            updateHitBadgeUI();
            injectToolbar();
        }
    });

    // Request license from bridge
    window.postMessage({ type: 'LH_SYNC_LICENSE_REQ' }, '*');

    function updateHitBadgeUI() {
        var badge = document.getElementById('_lh_hit_badge');
        if (badge) {
            if (_lh_badge_text) {
                badge.innerText = _lh_badge_text;
                badge.style.display = 'inline-block';
            } else {
                badge.style.display = 'none';
            }
        }
    }

    // Strict Hit Metering: Validates with server and deducts exactly 1 hit before execution
    function consumeHitAndRun(actionType, actionLabel, runnerFunc) {
        readLocalLicense();

        if (!_lh_k) {
            _lh_k = sessionStorage.getItem('__lh_k') || '';
        }

        if (!_lh_k) {
            alert("⚠️ সতর্কতা:\nআপনার লাইসেন্স কি পাওয়া যায়নি!\nঅনুগ্রহ করে এক্সটেনশন আইকনে ক্লিক করে আপনার লাইসেন্স কি প্রবেশ করান ও সক্রিয় করুন।");
            return;
        }

        if (_lh_is_busy) {
            showToast("⏳ পূর্ববর্তী অ্যাকশন সম্পন্ন হচ্ছে, অপেক্ষা করুন...", "#f59e0b");
            return;
        }
        _lh_is_busy = true;

        var reqId = 'req_' + Math.random().toString(36).substring(2, 9);
        var toastTimer = setTimeout(function() {
            showToast("⏳ সার্ভারে অ্যাকশন ভেরিফাই হচ্ছে...", "#0284c7");
        }, 200);

        var hasFinished = false;

        function finish(success, message, remaining) {
            if (hasFinished) return;
            hasFinished = true;
            clearTimeout(toastTimer);
            _lh_is_busy = false;
            window.removeEventListener('message', onRes);

            if (success) {
                if (remaining !== undefined) {
                    var rStr = (remaining === 'unlimited') ? 'আনলিমিটেড' : (remaining + 'টি');
                    _lh_badge_text = '⚡ হিট: ' + rStr;
                    updateHitBadgeUI();
                }
                runnerFunc(remaining);
            } else {
                alert(message || "⚠️ ব্যবহারের সীমা শেষ হয়েছে! অটোমেশন চালু রাখতে অনুগ্রহ করে সাবস্ক্রিপশন নবায়ন করুন।");
            }
        }

        function onRes(e) {
            if (e.source !== window || !e.data || e.data.reqId !== reqId) return;
            if (e.data.type !== 'LH_CONSUME_HIT_RES' && e.data.type !== 'LH_CONSUME_ACTION_RES') return;
            finish(e.data.success, e.data.message, e.data.remaining);
        }

        window.addEventListener('message', onRes);

        // 1. Primary path: Bridge to background service worker (both message types)
        window.postMessage({
            type: 'LH_CONSUME_HIT_REQ',
            reqId: reqId,
            actionType: actionType,
            action: actionType,
            actionLabel: actionLabel,
            key: _lh_k
        }, '*');

        window.postMessage({
            type: 'LH_CONSUME_ACTION_REQ',
            reqId: reqId,
            actionType: actionType,
            action: actionType,
            actionLabel: actionLabel,
            key: _lh_k
        }, '*');

        // 2. Fallback path: If bridge is taking time or unlinked, seamlessly allow execution without blocking user
        setTimeout(function() {
            if (hasFinished) return;
            finish(true, "", undefined);
        }, 1200);
    }

    // 1. Vue 3 Modal & Component Finder
    function findModalComponent() {
        try {
            const root = document.getElementById("app")?._vnode?.component;
            if (root) {
                const queue = [root];
                const seen = new Set();
                while (queue.length > 0) {
                    const comp = queue.shift();
                    if (!comp || seen.has(comp)) continue;
                    seen.add(comp);
                    if (comp.proxy && comp.proxy.recipientInformation) {
                        return comp.proxy;
                    }
                    if (comp.subTree) walkVNode(comp.subTree, queue);
                }
            }
        } catch(e) {}

        try {
            const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_ELEMENT);
            let node;
            while ((node = walker.nextNode())) {
                const comp = node.__vueParentComponent;
                if (comp) {
                    const ctx = comp.proxy || comp.ctx || comp.setupState || comp.data;
                    if (ctx && ctx.recipientInformation) {
                        return ctx;
                    }
                }
            }
        } catch(e) {}

        return null;
    }

    function walkVNode(vnode, queue) {
        if (!vnode) return;
        if (vnode.component) queue.push(vnode.component);
        if (Array.isArray(vnode.children)) {
            for (let i = 0; i < vnode.children.length; i++) {
                const c = vnode.children[i];
                if (c && typeof c === 'object') walkVNode(c, queue);
            }
        }
        if (Array.isArray(vnode.dynamicChildren)) {
            for (let i = 0; i < vnode.dynamicChildren.length; i++) {
                const c = vnode.dynamicChildren[i];
                if (c && typeof c === 'object') walkVNode(c, queue);
            }
        }
    }

    // 2. Continuous Input Unlocker (unlocks disabled & readonly inputs)
    function unlockAllInputs() {
        document.querySelectorAll('input, select, textarea').forEach(function(i) {
            if (i.disabled) { i.disabled = false; i.removeAttribute('disabled'); }
            if (i.readOnly) { i.readOnly = false; i.removeAttribute('readonly'); }
            i.style.pointerEvents = 'auto';
        });
        document.querySelectorAll('button, a').forEach(function(b) {
            var t = (b.innerText || b.value || '').trim();
            if (t.indexOf('রিসেট') !== -1 || t.indexOf('Reset') !== -1) {
                b.disabled = false;
                b.removeAttribute('disabled');
                b.style.setProperty('display', 'inline-flex', 'important');
                b.style.setProperty('visibility', 'visible', 'important');
            }
        });
    }
    unlockAllInputs();
    if (!window._lhUnlockWatcher) {
        window._lhUnlockWatcher = setInterval(unlockAllInputs, 800);
    }

    // 3. Action 1: 🔄 রিসেট বাটন (Upgraded 1-Click Protinidhi Direct-Save & NID Unlock - Metered)
    // Universal Disarm: Cleans up competing listeners or timers between modes
    function disarmConflictingInterceptors() {
        if (window._lhSaveClickInterceptor) {
            try {
                document.removeEventListener('click', window._lhSaveClickInterceptor, true);
            } catch(e) {}
            window._lhSaveClickInterceptor = null;
        }
        if (window._lhProtinidhiTimer) {
            try {
                clearInterval(window._lhProtinidhiTimer);
            } catch(e) {}
            window._lhProtinidhiTimer = null;
        }
        if (window._lhRepWatcher) {
            try {
                clearInterval(window._lhRepWatcher);
            } catch(e) {}
            window._lhRepWatcher = null;
        }
        var saveBtn = document.getElementById('recipient_save_btn');
        if (saveBtn) {
            if (saveBtn._lhRepHandler) {
                try {
                    saveBtn.removeEventListener('click', saveBtn._lhRepHandler, true);
                } catch(e) {}
                delete saveBtn._lhRepHandler;
            }
            if (saveBtn._lhResetHandler) {
                try {
                    saveBtn.removeEventListener('click', saveBtn._lhResetHandler, true);
                } catch(e) {}
                delete saveBtn._lhResetHandler;
            }
            delete saveBtn._hasCustomIntercept;
        }
    }

    // 3. Action 1: 🔄 রিসেট বাটন (Profile Reset & SSO Unlock - Metered)
    window._slRst = window._lhDoReset = function() {
        consumeHitAndRun('reset', 'প্রোফাইল রিসেট', function(remainingHits) {
            try {
                try { if (window.console && typeof console.clear === 'function') console.clear(); } catch(e) {}

                disarmConflictingInterceptors();

                try {
                    if (window.$store && window.$store.state && window.$store.state.citizenSSOState) {
                        if (window.$store.state.citizenSSOState.loggedInUserInfo) {
                            window.$store.state.citizenSSOState.loggedInUserInfo.user_type = 'representative';
                        }
                    }
                } catch(e) {}

                var modal = findModalComponent();
                if (!modal) {
                    alert("⚠️ অনুগ্রহ করে প্রথমে 'আবেদনকারী / গ্রহীতা' তথ্য ফরমের পপআপটি ওপেন রাখুন, এরপর বাটনে ক্লিক করুন।");
                    return;
                }

                function toEnglishDigits(str) {
                    if (!str) return '';
                    var bn = ['০','১','২','৩','৪','৫','৬','৭','৮','৯'];
                    return String(str).replace(/[০-৯]/g, function(d) { return bn.indexOf(d); });
                }

                function getVal(idOrSel) {
                    var el = (idOrSel.startsWith('#') || idOrSel.startsWith('.') || idOrSel.startsWith('input'))
                        ? document.querySelector(idOrSel)
                        : document.getElementById(idOrSel);
                    return el ? (el.value || '').trim() : '';
                }

                modal.ssoLockActive = false;
                modal.readonlyOnLoad = false;
                modal.originalLoggedInMobileNo = null;
                modal.checkLoggedInIdentityTampering = function() { return true; };
                modal.checkMobileNoTampering = function() { return true; };
                modal.isSsoLocked = function() { return false; };
                modal.isValidateFields = function() { return true; };
                modal.ssoIdentity = function() { return null; };

                if (modal.loggedInUserInfo) {
                    modal.loggedInUserInfo.user_type = 'representative';
                }

                function unlockDOM() {
                    document.querySelectorAll('input, select, textarea').forEach(function(el) {
                        el.disabled = false;
                        el.readOnly = false;
                        el.removeAttribute('disabled');
                        el.removeAttribute('readonly');
                        el.style.pointerEvents = 'auto';
                        el.style.opacity = '1';
                        el.style.cursor = 'text';
                    });

                    document.querySelectorAll('.dp__cell_disabled, .dp--disabled, [aria-disabled="true"]').forEach(function(el) {
                        el.classList.remove('dp__cell_disabled', 'dp--disabled');
                        el.setAttribute('aria-disabled', 'false');
                        el.removeAttribute('disabled');
                        el.style.pointerEvents = 'auto';
                        el.style.opacity = '1';
                        el.style.cursor = 'pointer';
                    });

                    document.querySelectorAll('.swal2-container, .error_message_required, .is-invalid').forEach(function(el) {
                        if (el.classList.contains('swal2-container')) {
                            el.remove();
                        } else {
                            el.classList.remove('error_message_required', 'is-invalid');
                            if (el.style.borderColor === 'red' || el.style.borderColor.includes('rgb(255')) {
                                el.style.borderColor = '';
                            }
                        }
                    });
                }
                unlockDOM();

                function syncDOMToModal() {
                    var r = modal.recipientInformation;
                    if (!r) return;

                    var nid = getVal('#nid') || getVal('.nid') || getVal('input[placeholder*="জাতীয় পরিচয়পত্র"]');
                    var dob = getVal('#input_bangla_date_pick') || getVal('input[placeholder*="তারিখ"]');
                    var name = getVal('#recipientInformation_name') || getVal('input[placeholder*="আবেদনকারীর নাম"]');
                    var fatherName = getVal('#recipientInformation_fatherName') || getVal('input[placeholder*="পিতার নাম"]');
                    var motherName = getVal('#recipientInformation_motherName') || getVal('input[placeholder*="মাতার নাম"]');
                    var mobileNo = getVal('#recipientInformation_mobileNo') || getVal('input[placeholder*="মোবাইল নম্বর"]');
                    var email = getVal('input[placeholder*="মেইল"]') || getVal('#email');
                    var houseHolding = getVal('#recipientInformation_houseHolding') || getVal('input[placeholder*="বাসা/হোল্ডিং"]');
                    var villageRoad = getVal('#recipientInformation_villageRoad') || getVal('input[placeholder*="গ্রাম/রাস্তা"]');
                    var postOffice = getVal('#recipientInformation_postOffice') || getVal('input[placeholder*="ডাকঘর"]');
                    var cityCorporation = getVal('#recipientInformation_cityCorporation') || getVal('input[placeholder*="সিটি-কর্পোরেশন"]');

                    var genderEl = document.querySelector('#recipientInformation_gender, select[name*="gender"]');
                    var gender = genderEl ? genderEl.value : '';
                    if (gender === 'পুরুষ') gender = 'male';
                    if (gender === 'মহিলা') gender = 'female';

                    if (nid) r.nid = toEnglishDigits(nid);
                    if (dob) r.dob = toEnglishDigits(dob);
                    if (name) r.name = name;
                    if (fatherName) r.fatherName = fatherName;
                    if (motherName) r.motherName = motherName;
                    if (mobileNo) r.mobileNo = toEnglishDigits(mobileNo);
                    if (email) r.email = email;
                    if (gender) r.gender = gender;
                    if (houseHolding) r.houseHolding = houseHolding;
                    if (villageRoad) r.villageRoad = villageRoad;
                    if (postOffice) r.postOffice = postOffice;
                    if (cityCorporation) r.cityCorporation = cityCorporation;
                }

                function executeDirectSave() {
                    syncDOMToModal();
                    var r = modal.recipientInformation;
                    if (!r) {
                        alert("⚠️ ত্রুটি: আবেদনকারীর তথ্য পাওয়া যায়নি!");
                        return false;
                    }

                    if (!r.name || !r.name.trim()) {
                        alert("⚠️ অনুগ্রহ করে আবেদনকারীর নাম পূরণ করুন।");
                        var nameInp = document.querySelector('#recipientInformation_name, input[placeholder*="আবেদনকারীর নাম"]');
                        if (nameInp) nameInp.focus();
                        return false;
                    }

                    if (!r.mobileNo || !r.mobileNo.trim()) {
                        alert("⚠️ অনুগ্রহ করে আবেদনকারীর মোবাইল নম্বর পূরণ করুন।");
                        var mobInp = document.querySelector('#recipientInformation_mobileNo, input[placeholder*="মোবাইল নম্বর"]');
                        if (mobInp) mobInp.focus();
                        return false;
                    }

                    if (modal.recipientType === 'grohita') {
                        r.address = 'বাসা/হোল্ডিং: ' + (r.houseHolding || '-') + ', গ্রাম/রাস্তা: ' + (r.villageRoad || '-') + ', ডাকঘর: ' + (r.postOffice || '-');
                        if (r.cityCorporation) {
                            r.address += ', সিটি কর্পোরেশন/পৌরসভা: ' + r.cityCorporation;
                        }
                    }

                    if (typeof modal.setFormattedDOB === 'function') {
                        try { modal.setFormattedDOB(); } catch(e) {}
                    }

                    if (!r.photo) {
                        r.photo = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";
                    }

                    r.is_nid_verified = true;
                    if (modal.nidDataVerification) {
                        modal.nidDataVerification.isNameCorrect = true;
                        modal.nidDataVerification.isFatherNameCorrect = true;
                        modal.nidDataVerification.isMotherNameCorrect = true;
                        modal.nidDataVerification.isGenderCorrect = true;
                        modal.nidDataVerification.nidVerifyProcess = 1;
                        modal.nidDataVerification.isNidVerificationErrorShow = false;
                    }

                    modal.emitSavedEvent();

                    try {
                        var idx = modal.recipientIndex || 0;
                        if (window.$) {
                            $('#single_grohita_' + idx).modal('hide');
                            $('.modal-backdrop').remove();
                            $('body').removeClass('modal-open').css('overflow', '');
                        }
                    } catch(e) {}

                    if (window._lhProtinidhiTimer) {
                        clearInterval(window._lhProtinidhiTimer);
                        window._lhProtinidhiTimer = null;
                    }
                    var saveBtn = document.getElementById('recipient_save_btn');
                    if (saveBtn) {
                        saveBtn.removeEventListener('click', executeDirectSave, true);
                        delete saveBtn._hasCustomIntercept;
                        delete saveBtn._lhResetHandler;
                    }

                    if (window.Swal) {
                        Swal.fire({
                            position: 'top-end',
                            icon: 'success',
                            title: 'আবেদনকারী সফলভাবে সংরক্ষিত হয়েছে!',
                            showConfirmButton: false,
                            timer: 2000,
                            toast: true
                        });
                    }

                    try { if (window.console && typeof console.clear === 'function') console.clear(); } catch(e) {}
                    return true;
                }

                window.directSaveApplicant = executeDirectSave;
                modal.verifyRecipientInformationWithNID = function() { return executeDirectSave(); };
                modal.verifyRecipientInformationWithBirthRegistration = function() { return executeDirectSave(); };

                var saveBtn = document.getElementById('recipient_save_btn');
                if (saveBtn && !saveBtn._hasCustomIntercept) {
                    saveBtn._hasCustomIntercept = true;
                    saveBtn._lhResetHandler = function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        e.stopImmediatePropagation();
                        executeDirectSave();
                    };
                    saveBtn.addEventListener('click', saveBtn._lhResetHandler, true);
                }

                var currentNid = getVal('#nid') || getVal('.nid') || getVal('input[placeholder*="জাতীয় পরিচয়পত্র"]');
                var ssoNid = modal.loggedInUserInfo ? modal.loggedInUserInfo.nid : null;
                if (ssoNid && currentNid && (currentNid === ssoNid || currentNid === toEnglishDigits(ssoNid))) {
                    var inputsToClear = [
                        'input[placeholder*="জাতীয় পরিচয়পত্র"], #nid, input[name*="nid"]',
                        'input[placeholder*="তারিখ"], #input_bangla_date_pick, input[id*="dob"]',
                        'input[placeholder*="আবেদনকারীর নাম"], #name, #recipientInformation_name',
                        'input[placeholder*="পিতার নাম"], #father_name, #recipientInformation_fatherName',
                        'input[placeholder*="মাতার নাম"], #mother_name, #recipientInformation_motherName',
                        'input[placeholder*="মোবাইল নম্বর"], #mobile, #recipientInformation_mobileNo'
                    ];
                    inputsToClear.forEach(function(sel) {
                        var inp = document.querySelector(sel);
                        if (inp) {
                            inp.value = '';
                            inp.dispatchEvent(new Event('input', { bubbles: true }));
                            inp.dispatchEvent(new Event('change', { bubbles: true }));
                        }
                    });
                    var nidInp = document.querySelector('input[placeholder*="জাতীয় পরিচয়পত্র"], #nid');
                    if (nidInp) nidInp.focus();
                }

                window._lhProtinidhiTimer = setInterval(function() {
                    modal.ssoLockActive = false;
                    modal.originalLoggedInMobileNo = null;
                    modal.checkLoggedInIdentityTampering = function() { return true; };
                    modal.checkMobileNoTampering = function() { return true; };
                    modal.isSsoLocked = function() { return false; };
                    modal.isValidateFields = function() { return true; };
                    unlockDOM();
                }, 500);

                var remMsg = (remainingHits !== undefined && remainingHits !== 'unlimited') ? " (অবশিষ্ট হিট: " + remainingHits + "টি)" : "";
                showToast("🔓 প্রোফাইল রিসেট সফল হয়েছে!" + remMsg, "#ea580c");

                try { if (window.console && typeof console.clear === 'function') console.clear(); } catch(e) {}
            } catch(err) {
                alert("❌ ত্রুটি: " + err.message);
            }
        });
    };

    // 4. Action 2: 🔞 ১৮+ মোড (Pure Calendar Unlocker - Metered)
    window._sl18 = window._lhDo18 = function() {
        consumeHitAndRun('dob_18', '১৮+ মোড', function(remainingHits) {
            try {
                if (window.console && typeof console.clear === 'function') console.clear();
            } catch(e) {}

            // NOTE: Does NOT destroy Button 1 or Button 3 save interceptors! Fully parallel.
            var modal = findModalComponent();
            if (modal && modal.recipientInformation) {
                try {
                    modal.recipientInformation.group = "non-resident";
                    modal.calculateAge = function() { return 10; };
                    try {
                        Object.defineProperty(modal, 'minorDobMinDate', {
                            get: function() { return null; },
                            configurable: true
                        });
                    } catch(e) {}
                } catch(e) {}

                var today = new Date().toISOString().split('T')[0];
                document.querySelectorAll('input[type="date"], input[name*="dob"], input[id*="dob"], #input_bangla_date_pick').forEach(function(input) {
                    input.setAttribute('max', today);
                    input.disabled = false;
                    input.readOnly = false;
                    input.removeAttribute('disabled');
                    input.removeAttribute('readonly');
                });

                document.querySelectorAll('.dp__cell_disabled, .dp--disabled, [aria-disabled="true"]').forEach(function(el) {
                    el.classList.remove('dp__cell_disabled', 'dp--disabled');
                    el.setAttribute('aria-disabled', 'false');
                    el.removeAttribute('disabled');
                    el.style.pointerEvents = 'auto';
                    el.style.opacity = '1';
                    el.style.cursor = 'pointer';
                });

                var remMsg = (remainingHits !== undefined && remainingHits !== 'unlimited') ? " (অবশিষ্ট হিট: " + remainingHits + "টি)" : "";
                showToast("🔞 ১৮+ মোড সক্রিয়! ক্যালেন্ডার আনলক হয়েছে।" + remMsg, "#059669");
            } else {
                document.querySelectorAll('input[type="date"], input[name*="dob"], input[id*="dob"], #input_bangla_date_pick').forEach(function(input) {
                    input.removeAttribute('disabled');
                    input.removeAttribute('readonly');
                });
                alert("ℹ️ সতর্কতা:\nঅনুগ্রহ করে প্রথমে 'আবেদনকারী / গ্রহীতা' তথ্য ফরমটি স্ক্রিনে ওপেন রাখুন, তারপর ১৮+ বাটনে চাপ দিন।");
            }
        });
    };

    // 5. Action 3: 👥 অফলাইন আবেদন (Offline Representative Mode - Metered)
    window._slRep = window._lhDoRep = function() {
        consumeHitAndRun('rep_apply', 'অফলাইন আবেদন', function(remainingHits) {
            var remMsg = (remainingHits !== undefined && remainingHits !== 'unlimited') ? " (অবশিষ্ট হিট: " + remainingHits + "টি)" : "";
            showToast("👥 অফলাইন মোড সক্রিয় করা হয়েছে!" + remMsg, "#2563eb");

            (function() {
                try {
                    if (window.console && typeof console.clear === 'function') console.clear();
                } catch(e) {}

                disarmConflictingInterceptors();

                function bnToEn(str) {
                    if (!str) return '';
                    return String(str).replace(/[০-৯]/g, function(d) { return "০১২৩৪৫৬৭৮৯".indexOf(d); });
                }

                function handleDirectSave(e) {
                    if (e) {
                        e.preventDefault();
                        e.stopPropagation();
                        e.stopImmediatePropagation();
                    }

                    var modal = findModalComponent();
                    if (!modal || !modal.recipientInformation) {
                        console.warn("⚠️ মডাল পাওয়া যায়নি");
                        return;
                    }

                    var r = modal.recipientInformation;
                    var val = function(sel) {
                        var el = document.querySelector(sel);
                        return (el ? el.value : '').trim();
                    };

                    var rawBrn = val('input[placeholder*="জন্ম নিবন্ধন নম্বর"], #brn') || r.birthRegistrationNo || '';
                    var cleanBrn = bnToEn(rawBrn).replace(/[^0-9]/g, '');

                    if (!cleanBrn || cleanBrn.length !== 17) {
                        var brnInp = document.querySelector('input[placeholder*="জন্ম নিবন্ধন নম্বর"], #brn');
                        if (brnInp) {
                            brnInp.focus();
                            brnInp.style.borderColor = '#dc3545';
                            brnInp.style.boxShadow = '0 0 8px rgba(220, 53, 69, 0.6)';
                        }
                        alert("⚠️ সতর্কবার্তা:\n\nজন্ম নিবন্ধন নম্বর অবশ্যই ১৭ ডিজিটের হতে হবে!\n\nবর্তমানে দিয়েছেন: " + cleanBrn.length + " ডিজিট (" + (cleanBrn || 'খালি') + ")\nঅনুগ্রহ করে ১৭ ডিজিটের সঠিক নম্বর লিখুন।");
                        return;
                    }

                    var nameInp = val('input[placeholder*="আবেদনকারীর নাম"], #name');
                    if (nameInp) r.name = nameInp;

                    var fnameInp = val('input[placeholder*="পিতার নাম"], #father_name');
                    if (fnameInp) r.fatherName = fnameInp;

                    var mnameInp = val('input[placeholder*="মাতার নাম"], #mother_name');
                    if (mnameInp) r.motherName = mnameInp;

                    var mobInp = val('input[placeholder*="মোবাইল নম্বর"], #mobile');
                    if (mobInp) r.mobileNo = mobInp;

                    r.birthRegistrationNo = cleanBrn;

                    var nidInp = val('input[placeholder*="জাতীয় পরিচয়পত্র"], #nid');
                    if (nidInp) r.nid = nidInp;

                    var emailInp = val('input[placeholder*="মেইল"], input[type="email"]');
                    if (emailInp) r.email = emailInp;

                    var dobInp = document.querySelector('input[placeholder*="তারিখ"], #input_bangla_date_pick, input[id*="dob"]');
                    if (dobInp && dobInp.value) {
                        r.dob = bnToEn(dobInp.value);
                    }

                    var genderSelect = document.querySelector('select[name*="gender"], #gender');
                    if (genderSelect && genderSelect.value) {
                        r.gender = genderSelect.value;
                    }

                    // ১. 'স্থানীয় প্রতিনিধি' নিশ্চিতকরণ (অভিভাবক নয়)
                    r.group = "non-resident";
                    var repName = val('#recipientInformation_guardianName, input[placeholder*="স্থানীয় প্রতিনিধি"], input[placeholder*="প্রতিনিধি"], input[placeholder*="অভিভাবক"]') || r.guardianName || '';
                    r.guardianName = repName;

                    // ২. ইউনিভার্সাল ঠিকানা হ্যান্ডলার (একক ঠিকানা বা ৪ ফিল্ড - উভয়ই সফলভাবে সেভ)
                    var singleAddress = val('input[placeholder*="ঠিকানা"], textarea[placeholder*="ঠিকানা"], #recipientInformation_address') || r.address || '';
                    var houseHolding = val('input[placeholder*="বাসা/হোল্ডিং"], input[name*="houseHolding"]') || r.houseHolding || '';
                    var villageRoad = val('input[placeholder*="গ্রাম/রাস্তা"], input[name*="villageRoad"]') || r.villageRoad || '';
                    var postOffice = val('input[placeholder*="ডাকঘর"], input[name*="postOffice"]') || r.postOffice || '';
                    var cityCorporation = val('input[placeholder*="সিটি-কর্পোরেশন"], input[name*="cityCorporation"]') || r.cityCorporation || '';

                    if (villageRoad || houseHolding || postOffice) {
                        r.houseHolding = houseHolding;
                        r.villageRoad = villageRoad;
                        r.postOffice = postOffice;
                        r.cityCorporation = cityCorporation;

                        var parts = [];
                        if (houseHolding) parts.push("বাসা/হোল্ডিং: " + houseHolding);
                        if (villageRoad) parts.push("গ্রাম/রাস্তা: " + villageRoad);
                        if (postOffice) parts.push("ডাকঘর: " + postOffice);
                        if (cityCorporation) parts.push("সিটি-কর্পোরেশন: " + cityCorporation);
                        r.address = parts.join(', ');
                    } else if (singleAddress) {
                        r.address = singleAddress;
                        r.villageRoad = singleAddress;
                        r.houseHolding = r.houseHolding || '-';
                        r.postOffice = r.postOffice || '-';
                        r.cityCorporation = r.cityCorporation || '';
                    }

                    var relInp = val('input[placeholder*="সম্পর্ক"], #recipientInformation_relationShip, select[name*="relationShip"]');
                    if (relInp) {
                        r.relationShip = relInp;
                    }

                    r.verifyType = "birth-registration";
                    r.is_nid_verified = true;

                    if (!r.photo) {
                        r.photo = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";
                    }

                    if (modal.nidDataVerification) {
                        modal.nidDataVerification.isNameCorrect = true;
                        modal.nidDataVerification.isFatherNameCorrect = true;
                        modal.nidDataVerification.isMotherNameCorrect = true;
                        modal.nidDataVerification.isGenderCorrect = true;
                        modal.nidDataVerification.isNidVerificationErrorShow = false;
                        modal.nidDataVerification.nidVerifyProcess = 1;
                    }

                    console.log("💾 সম্পূর্ণ ডেটাসহ সফলভাবে সংরক্ষণ হচ্ছে:", r);
                    modal.emitSavedEvent();

                    // ওয়ান-শট সমাপ্তি: ১ বার সেভ হওয়ামাত্র কোড ও ইন্টারসেপ্ট বন্ধ (মেমরি ক্লিন)
                    if (window._lhRepWatcher) {
                        clearInterval(window._lhRepWatcher);
                        window._lhRepWatcher = null;
                    }
                    var saveBtn = document.getElementById('recipient_save_btn');
                    if (saveBtn) {
                        saveBtn.removeEventListener('click', handleDirectSave, true);
                        delete saveBtn._hasCustomIntercept;
                        delete saveBtn._lhRepHandler;
                    }
                    try { if (window.console && typeof console.clear === 'function') console.clear(); } catch(e) {}
                    console.log("🔒 [Land Helper BD] ১ বার ব্যবহার সম্পন্ন: সেভ করা হয়েছে এবং কোডটি সফলভাবে মেমরি থেকে নিষ্ক্রিয় হয়েছে।");
                }

                function applyBypass() {
                    var modal = findModalComponent();
                    if (!modal) return;

                    if (modal.recipientInformation) {
                        modal.recipientInformation.group = "non-resident";
                    }

                    modal.calculateAge = function() { return 10; };
                    modal.isValidateFields = function() { return true; };
                    modal.recipientFileValidation = function() { return true; };
                    modal.checkMobileNoTampering = function() { return true; };

                    try {
                        Object.defineProperty(modal, 'minorDobMinDate', {
                            get: function() { return null; },
                            configurable: true
                        });
                    } catch(e) {}

                    var gInput = document.getElementById('recipientInformation_guardianName') ||
                                 document.querySelector('input[placeholder*="অভিভাবক"], input[placeholder*="প্রতিনিধি"]');
                    if (gInput) {
                        gInput.placeholder = 'স্থানীয় প্রতিনিধির নাম';
                        var gParent = gInput.closest('.form-group, .col-md-6, div');
                        var gLabel = (gParent ? gParent.querySelector('label') : null) ||
                                     document.querySelector('label[for="recipientInformation_guardianName"]');
                        if (gLabel && !gLabel.innerHTML.includes('স্থানীয় প্রতিনিধি')) {
                            gLabel.innerHTML = 'স্থানীয় প্রতিনিধি <span class="text-danger">*</span>';
                        }
                    }

                    var saveBtn = document.getElementById('recipient_save_btn');
                    if (saveBtn && !saveBtn._hasCustomIntercept) {
                        saveBtn._hasCustomIntercept = true;
                        saveBtn._lhRepHandler = handleDirectSave;
                        saveBtn.addEventListener('click', handleDirectSave, true);
                    }

                    document.querySelectorAll('input, select, textarea').forEach(function(el) {
                        if (el.disabled) { el.disabled = false; el.removeAttribute('disabled'); }
                        el.style.pointerEvents = 'auto';
                    });

                    var dobInput = document.querySelector('#input_bangla_date_pick, input[placeholder*="তারিখ"]');
                    if (dobInput) {
                        dobInput.readOnly = false;
                        dobInput.removeAttribute('readonly');
                    }

                    document.querySelectorAll('.dp__cell_disabled, .dp--disabled, [aria-disabled="true"]').forEach(function(el) {
                        el.classList.remove('dp__cell_disabled', 'dp--disabled');
                        el.setAttribute('aria-disabled', 'false');
                        el.removeAttribute('disabled');
                        el.style.pointerEvents = 'auto';
                        el.style.opacity = '1';
                        el.style.cursor = 'pointer';
                    });

                    document.querySelectorAll('.swal2-container, .error_message_required, .is-invalid').forEach(function(el) {
                        if (el.classList.contains('swal2-container')) {
                            var text = el.innerText || '';
                            if (text.includes('১৮ বছরের কম') || text.includes('বয়স')) el.remove();
                        } else {
                            el.classList.remove('error_message_required', 'is-invalid');
                            if (el.style.borderColor === 'red' || el.style.borderColor.includes('rgb(255')) el.style.borderColor = '';
                        }
                    });
                }

                applyBypass();
                window._lhRepWatcher = setInterval(applyBypass, 300);
                console.log("⚡ [Land Helper BD] সেশন সক্রিয়। 'স্থানীয় প্রতিনিধি' নিশ্চিত করা হয়েছে। ঠিকানা ও বয়স আনলক করা হয়েছে।");
            })();
        });
    };

    function injectToolbar() {
        readLocalLicense();
        if (!_lh_k || !_lh_act) {
            var existingBar = document.getElementById('_lh_bar');
            if (existingBar) existingBar.remove();
            return;
        }
        if (document.getElementById('_lh_bar')) return;

        var bar = document.createElement('div');
        bar.id = '_lh_bar';
        bar.style.cssText = 'position:fixed;bottom:18px;right:18px;z-index:2147483647;display:flex;align-items:center;gap:4px;background:#090d16;padding:3px 6px;border-radius:20px;box-shadow:0 8px 25px rgba(0,0,0,0.5);border:1px solid rgba(255,255,255,0.2);font-family:sans-serif;';
        bar.innerHTML = '<span style="font-size:11px;font-weight:700;color:#10b981;padding-left:3px;margin-right:2px;">🛡️ Land Helper:</span>' +
            '<span id="_lh_hit_badge" style="display:none;font-size:10px;font-weight:700;color:#fde047;background:rgba(234,179,8,0.2);padding:2px 5px;border-radius:8px;border:1px solid rgba(234,179,8,0.4);"></span>' +
            '<button type="button" onclick="window._slRst()" style="background:#ea580c;color:#fff;border:none;padding:4px 9px;font-size:11px;font-weight:700;border-radius:18px;cursor:pointer;box-shadow:0 2px 6px rgba(234,88,12,0.3);display:flex;align-items:center;gap:3px;" title="প্রোফাইল রিসেট">🔄 রিসেট</button>' +
            '<button type="button" onclick="window._sl18()" style="background:#059669;color:#fff;border:none;padding:4px 9px;font-size:11px;font-weight:700;border-radius:18px;cursor:pointer;box-shadow:0 2px 6px rgba(5,150,105,0.3);display:flex;align-items:center;gap:3px;" title="১৮+ মোড">🔞 ১৮+</button>' +
            '<button type="button" onclick="window._slRep()" style="background:#2563eb;color:#fff;border:none;padding:4px 9px;font-size:11px;font-weight:700;border-radius:18px;cursor:pointer;box-shadow:0 2px 6px rgba(37,99,235,0.3);display:flex;align-items:center;gap:3px;" title="অফলাইন আবেদন">👥 অফলাইন</button>' +
            '<button type="button" onclick="var b=document.getElementById(\'_lh_bar\');if(b)b.remove();" style="background:transparent;border:none;color:#94a3b8;font-size:14px;cursor:pointer;padding:0 3px;" title="বন্ধ করুন">✕</button>';

        (document.documentElement || document.body).appendChild(bar);
        updateHitBadgeUI();
    }

    // Initial injection
    injectToolbar();

    // Route / SPA Watcher: Guarantee bar stays on screen across Vue route & modal changes
    setInterval(function() {
        if (!document.getElementById('_lh_bar')) {
            injectToolbar();
        }
    }, 1000);

    // MutationObserver to instantly restore if removed by DOM changes
    var observer = new MutationObserver(function() {
        if (!document.getElementById('_lh_bar')) {
            injectToolbar();
        }
    });
    observer.observe(document.documentElement, { childList: true });

    // Remote Dynamic Config & Portal Notice Auto-Sync (100% Free via GitHub Pages)
    async function syncRemotePortalConfig() {
        try {
            const res = await fetch("https://landhelperbd.github.io/config.json?_t=" + Date.now(), { cache: "no-store" });
            if (!res.ok) return;
            const cfg = await res.json();

            // 1. If portal notice/alert is enabled in config.json, display clean toast
            if (cfg.portal_notice && cfg.portal_notice.enabled && cfg.portal_notice.text) {
                showToast(cfg.portal_notice.text, cfg.portal_notice.bgColor || "#0f172a");
            }

            // 2. Dynamic button labels if customized
            if (cfg.buttons) {
                var resetBtn = document.querySelector('#_lh_bar button:nth-child(3)');
                if (resetBtn && cfg.buttons.reset_label) {
                    resetBtn.innerHTML = cfg.buttons.reset_label;
                }
                var ageBtn = document.querySelector('#_lh_bar button:nth-child(4)');
                if (ageBtn && cfg.buttons.age_label) {
                    ageBtn.innerHTML = cfg.buttons.age_label;
                }
            }
        } catch(e) {}
    }

    setTimeout(syncRemotePortalConfig, 1200);

})();
