// Land Helper BD Pro v2.0 - Intelligent Automation Engine
// Zero-Knowledge Ephemeral Controller (Maintained strictly outside webpage DOM)

const API_BASE = "https://landseba.com";

// Elements
const lockoutScreen = document.getElementById("lockout-screen");
const loginScreen = document.getElementById("login-screen");
const dashboardScreen = document.getElementById("dashboard-screen");
const statusBadge = document.getElementById("status-badge");
const toast = document.getElementById("toast");

const custName = document.getElementById("cust-name");
const custKey = document.getElementById("cust-key");
const custPlan = document.getElementById("cust-plan");
const custValidity = document.getElementById("cust-validity");

const licenseInput = document.getElementById("license-input");
const btnLogin = document.getElementById("btn-login");
const btnReset = document.getElementById("btn-reset");
const btnDob = document.getElementById("btn-dob");
const btnRep = document.getElementById("btn-rep");
const btnRescan = document.getElementById("btn-rescan");
const btnLogout = document.getElementById("btn-logout");

let currentKey = "";
let currentFp = "";

function getDeviceFp() {
  try {
    const raw = navigator.userAgent + screen.width + "x" + screen.height + (navigator.hardwareConcurrency || 1);
    return btoa(raw).substring(0, 32);
  } catch(e) {
    return "PC-DEFAULT-V2";
  }
}
currentFp = getDeviceFp();

function showToast(msg, type = "info", duration = 4000) {
  if (!toast) return;
  toast.innerText = msg;
  toast.className = `toast-${type}`;
  toast.style.display = "block";
  if (duration > 0) {
    setTimeout(() => {
      toast.style.display = "none";
    }, duration);
  }
}

// =============================================================================
// STEP 1: Old Version Conflict Check
// =============================================================================
async function scanForOldVersions() {
  try {
    const allExtensions = await new Promise(resolve => chrome.management.getAll(resolve));
    const myId = chrome.runtime.id;
    
    const conflictExt = allExtensions.find(ext => {
      if (ext.id === myId) return false;
      const n = (ext.name || "").toLowerCase();
      return (n.includes("land helper") || n.includes("land_helper") || n.includes("landhelper")) && ext.enabled;
    });

    if (conflictExt) {
      return { conflict: true, reason: `পুরনো এক্সটেনশন ("${conflictExt.name}") এখনও ব্রাউজারে সক্রিয় আছে!` };
    }
    return { conflict: false };
  } catch(err) {
    return { conflict: false };
  }
}

// =============================================================================
// STEP 2: Main Init
// =============================================================================
async function init() {
  if (toast) toast.style.display = "none";
  
  const scan = await scanForOldVersions();
  if (scan.conflict) {
    lockoutScreen.style.display = "block";
    loginScreen.style.display = "none";
    dashboardScreen.style.display = "none";
    statusBadge.className = "status-badge status-locked";
    statusBadge.innerText = "● Blocked";
    showToast(scan.reason, "error", 0);
    return;
  }

  lockoutScreen.style.display = "none";

  const stored = await chrome.storage.local.get(["lh_license_key"]);
  if (!stored.lh_license_key) {
    showLoginScreen();
    return;
  }

  currentKey = stored.lh_license_key;
  await verifyAndLoadDashboard(currentKey);
}

function showLoginScreen() {
  loginScreen.style.display = "block";
  dashboardScreen.style.display = "none";
  statusBadge.className = "status-badge status-active";
  statusBadge.innerText = "● Waiting Key";
}

async function verifyAndLoadDashboard(key) {
  showToast("⌛ লাইসেন্স তথ্য যাচাই হচ্ছে...", "info", 1500);
  try {
    const res = await fetch(`${API_BASE}/api/v2/auth-status`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ k: key, fp: currentFp })
    });
    const data = await res.json();
    if (!data.success) {
      showToast(data.message || "অবৈধ লাইসেন্স কি!", "error");
      showLoginScreen();
      return;
    }

    loginScreen.style.display = "none";
    dashboardScreen.style.display = "block";
    statusBadge.className = "status-badge status-active";
    statusBadge.innerText = "● Active";

    custName.innerText = data.customer_name || "সম্মানিত গ্রাহক";
    custKey.innerText = key;
    custValidity.innerText = (data.expires_at || "Lifetime").split(" ")[0];
    custPlan.innerText = data.status === "active" ? "Verified Active" : data.status;

    // Dynamic server-driven button labels (no client update needed for future renames!)
    if (data.buttons) {
      const lr = document.getElementById("lbl-reset");
      const ld = document.getElementById("lbl-dob");
      const lp = document.getElementById("lbl-rep");
      if (lr && data.buttons.reset) lr.innerText = data.buttons.reset;
      if (ld && data.buttons.dob) ld.innerText = data.buttons.dob;
      if (lp && data.buttons.offline) lp.innerText = data.buttons.offline;
    }

    await chrome.storage.local.set({ lh_license_key: key });
  } catch(err) {
    showToast("সার্ভারে সংযোগ করা যায়নি: " + err.message, "error");
    showLoginScreen();
  }
}

// =============================================================================
// STEP 3: Exact Mutation Tab Discovery (Strictly targets mutation.land.gov.bd)
// =============================================================================
async function findMutationTab() {
  // 1. Active tab in last focused window
  try {
    const tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tabs && tabs[0] && tabs[0].url && tabs[0].url.includes("mutation.land.gov.bd")) {
      return tabs[0];
    }
  } catch(e) {}

  // 2. Active tab in current window
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tabs && tabs[0] && tabs[0].url && tabs[0].url.includes("mutation.land.gov.bd")) {
      return tabs[0];
    }
  } catch(e) {}

  // 3. Any open mutation.land.gov.bd tab (prefer active one)
  try {
    const mutTabs = await chrome.tabs.query({ url: "*://mutation.land.gov.bd/*" });
    if (mutTabs && mutTabs.length > 0) {
      const activeMut = mutTabs.find(t => t.active);
      return activeMut || mutTabs[0];
    }
  } catch(e) {}

  return null;
}

// =============================================================================
// STEP 4: Ephemeral Action Execution (Runs directly in Page MAIN World)
// =============================================================================
async function triggerAction(actionType, btnElement, label) {
  const targetTab = await findMutationTab();
  
  if (!targetTab || !targetTab.id) {
    showToast("⚠️ mutation.land.gov.bd পেজটি ব্রাউজারে ওপেন পাওয়া যায়নি!", "error", 5000);
    return;
  }

  if (btnReset) btnReset.disabled = true;
  if (btnDob) btnDob.disabled = true;
  if (btnRep) btnRep.disabled = true;
  showToast(`⌛ সার্ভার থেকে ${label} কোড আনা হচ্ছে...`, "info", 0);

  try {
    const res = await fetch(`${API_BASE}/api/v2/action-payload`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        k: currentKey,
        fp: currentFp,
        action: actionType,
        v: "2.0.0"
      })
    });
    const data = await res.json();
    if (!data.success || !data.payload) {
      showToast("❌ " + (data.message || "সার্ভার থেকে কোড পাওয়া যায়নি!"), "error", 5000);
      return;
    }

    // Execute directly in MAIN world of mutation.land.gov.bd tab
    const execResults = await chrome.scripting.executeScript({
      target: { tabId: targetTab.id },
      world: "MAIN",
      func: (b64Payload) => {
        try {
          const bin = atob(b64Payload);
          const bytes = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) {
            bytes[i] = bin.charCodeAt(i);
          }
          const rawCode = new TextDecoder("utf-8").decode(bytes);
          try {
            (0, eval)(rawCode);
          } catch (evalErr) {
            const runFn = new Function(rawCode);
            runFn();
          }
          return { success: true };
        } catch(e) {
          return { success: false, error: e.message || String(e) };
        }
      },
      args: [data.payload]
    });

    const result = execResults && execResults[0] && execResults[0].result;
    if (result && result.success) {
      showToast(`✅ ${label} সফলভাবে কার্যকর হয়েছে!`, "success", 4000);
    } else {
      const errMsg = (result && result.error) ? result.error : "পেজে স্ক্রিপ্ট রান করতে ব্যর্থ হয়েছে";
      showToast(`❌ ত্রুটি: ${errMsg}`, "error", 6000);
    }
  } catch(err) {
    showToast("❌ ত্রুটি: " + (err.message || String(err)), "error", 6000);
  } finally {
    if (btnReset) btnReset.disabled = false;
    if (btnDob) btnDob.disabled = false;
    if (btnRep) btnRep.disabled = false;
  }
}

// Event Listeners
if (btnLogin) {
  btnLogin.addEventListener("click", async () => {
    const k = licenseInput.value.trim();
    if (!k) {
      showToast("দয়া করে লাইসেন্স কি প্রদান করুন!", "error");
      return;
    }
    currentKey = k;
    await verifyAndLoadDashboard(k);
  });
}

if (btnReset) {
  btnReset.addEventListener("click", () => {
    triggerAction("reset_btn", btnReset, "তথ্য রিসেট");
  });
}

if (btnDob) {
  btnDob.addEventListener("click", () => {
    triggerAction("dob_btn", btnDob, "১৮+ আনলক");
  });
}

if (btnRep) {
  btnRep.addEventListener("click", () => {
    const lbl = document.getElementById("lbl-rep")?.innerText || "অফলাইন জন্ম নিবন্ধন";
    triggerAction("offline_rep", btnRep, lbl);
  });
}

if (btnRescan) {
  btnRescan.addEventListener("click", async () => {
    showToast("🔄 সিস্টেম রি-স্ক্যান হচ্ছে...", "info", 1500);
    await init();
  });
}

if (btnLogout) {
  btnLogout.addEventListener("click", async () => {
    await chrome.storage.local.remove(["lh_license_key"]);
    currentKey = "";
    showLoginScreen();
  });
}

document.addEventListener("DOMContentLoaded", init);
