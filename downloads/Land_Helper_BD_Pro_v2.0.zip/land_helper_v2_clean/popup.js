// Land Helper BD Pro v2.0 - Intelligent Automation Engine
// Zero-Knowledge Ephemeral Controller (Maintained strictly outside webpage DOM)

const API_BASE = "https://landseba.com";

// Elements
const lockoutScreen = document.getElementById("lockout-screen");
const loginScreen = document.getElementById("login-screen");
const dashboardScreen = document.getElementById("dashboard-screen");
const statusBadge = document.getElementById("status-badge");
const toast = document.getElementById("toast");

const custName = document.getElementById("cust-name");
const custKey = document.getElementById("cust-key");
const custPlan = document.getElementById("cust-plan");
const custValidity = document.getElementById("cust-validity");

const licenseInput = document.getElementById("license-input");
const btnLogin = document.getElementById("btn-login");
const btnReset = document.getElementById("btn-reset");
const btnDob = document.getElementById("btn-dob");
const btnRescan = document.getElementById("btn-rescan");
const btnLogout = document.getElementById("btn-logout");

let currentKey = "";
let currentFp = "";

// Generate / read stable device fingerprint
function getDeviceFp() {
  try {
    const raw = navigator.userAgent + screen.width + "x" + screen.height + (navigator.hardwareConcurrency || 1);
    return btoa(raw).substring(0, 32);
  } catch(e) {
    return "PC-DEFAULT-V2";
  }
}
currentFp = getDeviceFp();

// Toast helper
function showToast(msg, type = "info", duration = 3500) {
  toast.innerText = msg;
  toast.className = `toast-${type}`;
  toast.style.display = "block";
  if (duration > 0) {
    setTimeout(() => {
      toast.style.display = "none";
    }, duration);
  }
}

// =============================================================================
// STEP 1: Old Version & Lingering Conflict Detector (Hard Gate)
// =============================================================
async function scanForOldVersions() {
  try {
    // A. Check Chrome Management for any other Land Helper extensions
    const allExtensions = await new Promise(resolve => chrome.management.getAll(resolve));
    const myId = chrome.runtime.id;
    
    const conflictExt = allExtensions.find(ext => {
      if (ext.id === myId) return false;
      const n = (ext.name || "").toLowerCase();
      return n.includes("land helper") || n.includes("land_helper") || n.includes("landhelper");
    });

    if (conflictExt) {
      console.warn("Conflict detected:", conflictExt.name);
      return { conflict: true, reason: `পুরনো এক্সটেনশন ("${conflictExt.name}") এখনও ব্রাউজারে সক্রিয় আছে!` };
    }

    // B. Check active tab for old leftover floating bar
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.url && tab.url.includes("mutation.land.gov.bd")) {
      try {
        const checkResults = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          world: "MAIN",
          func: () => Boolean(document.getElementById("_lh_bar") || window._lh_main_controller_loaded)
        });
        if (checkResults && checkResults[0] && checkResults[0].result === true) {
          return { conflict: true, reason: "পেজে পুরনো ভাসমান বারের কোড এখনও ক্যাশ হয়ে আছে! ব্রাউজারটি রিস্টার্ট করুন।" };
        }
      } catch(e) {}
    }

    return { conflict: false };
  } catch(err) {
    console.error("Scan error:", err);
    return { conflict: false };
  }
}

// =============================================================================
// STEP 2: Main Initialization & Auth Status
// =============================================================================
async function init() {
  toast.style.display = "none";
  
  // 1. Run Conflict Detector
  const scan = await scanForOldVersions();
  if (scan.conflict) {
    lockoutScreen.style.display = "block";
    loginScreen.style.display = "none";
    dashboardScreen.style.display = "none";
    statusBadge.className = "status-badge status-locked";
    statusBadge.innerText = "● Blocked";
    showToast(scan.reason, "error", 0);
    return;
  }

  lockoutScreen.style.display = "none";

  // 2. Read stored license key
  const stored = await chrome.storage.local.get(["lh_license_key"]);
  if (!stored.lh_license_key) {
    showLoginScreen();
    return;
  }

  currentKey = stored.lh_license_key;
  await verifyAndLoadDashboard(currentKey);
}

function showLoginScreen() {
  loginScreen.style.display = "block";
  dashboardScreen.style.display = "none";
  statusBadge.className = "status-badge status-active";
  statusBadge.innerText = "● Waiting Key";
}

async function verifyAndLoadDashboard(key) {
  showToast("⌛ লাইসেন্স তথ্য যাচাই হচ্ছে...", "info", 2000);
  try {
    const res = await fetch(`${API_BASE}/api/v2/auth-status`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ k: key, fp: currentFp })
    });
    const data = await res.json();
    if (!data.success) {
      showToast(data.message || "অবৈধ লাইসেন্স কি!", "error");
      showLoginScreen();
      return;
    }

    // Active
    loginScreen.style.display = "none";
    dashboardScreen.style.display = "block";
    statusBadge.className = "status-badge status-active";
    statusBadge.innerText = "● Active";

    custName.innerText = data.customer_name || "সম্মানিত গ্রাহক";
    custKey.innerText = key;
    custValidity.innerText = (data.expires_at || "Lifetime").split(" ")[0];
    custPlan.innerText = data.status === "active" ? "Verified Active" : data.status;

    await chrome.storage.local.set({ lh_license_key: key });
  } catch(err) {
    showToast("সার্ভারে সংযোগ করা যায়নি: " + err.message, "error");
    showLoginScreen();
  }
}

// =============================================================================
// STEP 3: Ephemeral Action Execution (Team Agent Zero Architecture)
// =============================================================================
async function triggerAction(actionType, btnElement, label) {
  // A. Check active tab
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url || !tab.url.includes("mutation.land.gov.bd")) {
    showToast("⚠️ দয়া করে ই-নামজারি আবেদন পেজে (mutation.land.gov.bd) যান!", "error");
    return;
  }

  // B. Disable buttons
  btnReset.disabled = true;
  btnDob.disabled = true;
  showToast(`⌛ সার্ভার থেকে ${label} কমান্ড আনা হচ্ছে...`, "info", 0);

  try {
    const res = await fetch(`${API_BASE}/api/v2/action-payload`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        k: currentKey,
        fp: currentFp,
        action: actionType,
        v: "2.0.0"
      })
    });
    const data = await res.json();
    if (!data.success) {
      showToast(data.message || "অ্যাকশন ব্যর্থ হয়েছে!", "error");
      btnReset.disabled = false;
      btnDob.disabled = false;
      return;
    }

    // C. One-shot Execution in MAIN world of the active tab
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: (b64Payload) => {
        try {
          // Decode Base64 to UTF-8
          const decoded = decodeURIComponent(escape(atob(b64Payload)));
          const s = document.createElement("script");
          s.textContent = decoded;
          (document.head || document.documentElement).appendChild(s);
          s.remove(); // Removed immediately from DOM!
        } catch(e) {
          alert("❌ এক্সিকিউশন ত্রুটি: " + e.message);
        }
      },
      args: [data.payload]
    });

    showToast(`✅ ${label} সফলভাবে সম্পন্ন হয়েছে!`, "success", 4000);
  } catch(err) {
    showToast("ত্রুটি: " + err.message, "error");
  } finally {
    btnReset.disabled = false;
    btnDob.disabled = false;
  }
}

// Event Listeners
btnLogin.addEventListener("click", async () => {
  const k = licenseInput.value.trim();
  if (!k) {
    showToast("দয়া করে লাইসেন্স কি প্রদান করুন!", "error");
    return;
  }
  currentKey = k;
  await verifyAndLoadDashboard(k);
});

btnReset.addEventListener("click", () => {
  triggerAction("reset_btn", btnReset, "তথ্য রিসেট");
});

btnDob.addEventListener("click", () => {
  triggerAction("dob_btn", btnDob, "জন্মতারিখ ১৮+");
});

btnRescan.addEventListener("click", async () => {
  showToast("🔄 সিস্টেম রি-স্ক্যান হচ্ছে...", "info", 1500);
  await init();
});

btnLogout.addEventListener("click", async () => {
  await chrome.storage.local.remove(["lh_license_key"]);
  currentKey = "";
  showLoginScreen();
});

// Run
document.addEventListener("DOMContentLoaded", init);
