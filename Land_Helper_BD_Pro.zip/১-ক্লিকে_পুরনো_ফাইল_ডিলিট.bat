@echo off
chcp 65001 >nul
title Land Helper BD - পুরনো ভার্সন ক্লিনআপ ইউটিলিটি
color 0A

echo ==============================================================================
echo           LAND HELPER BD - পিসি সম্পূর্ণ ক্লিনআপ ও সিকিউরিটি ইউটিলিটি
echo ==============================================================================
echo.
echo [1/3] আপনার পিসির Downloads ও Desktop ফোল্ডার স্ক্যান করা হচ্ছে...
echo.

:: 1. Downloads Folder
if exist "%USERPROFILE%\Downloads\*Land_Helper*" (
    echo [!] Downloads ফোল্ডারে পুরনো ফাইল পাওয়া গেছে। ডিলিট করা হচ্ছে...
    del /f /q "%USERPROFILE%\Downloads\*Land_Helper*" 2>nul
    for /d %%p in ("%USERPROFILE%\Downloads\*Land_Helper*") do rmdir /s /q "%%p" 2>nul
)
if exist "%USERPROFILE%\Downloads\*land_helper*" (
    del /f /q "%USERPROFILE%\Downloads\*land_helper*" 2>nul
    for /d %%p in ("%USERPROFILE%\Downloads\*land_helper*") do rmdir /s /q "%%p" 2>nul
)
if exist "%USERPROFILE%\Downloads\*LandHelper*" (
    del /f /q "%USERPROFILE%\Downloads\*LandHelper*" 2>nul
    for /d %%p in ("%USERPROFILE%\Downloads\*LandHelper*") do rmdir /s /q "%%p" 2>nul
)

:: 2. Desktop Folder
if exist "%USERPROFILE%\Desktop\*Land_Helper*" (
    echo [!] Desktop ফোল্ডারে পুরনো ফাইল পাওয়া গেছে। ডিলিট করা হচ্ছে...
    del /f /q "%USERPROFILE%\Desktop\*Land_Helper*" 2>nul
    for /d %%p in ("%USERPROFILE%\Desktop\*Land_Helper*") do rmdir /s /q "%%p" 2>nul
)
if exist "%USERPROFILE%\Desktop\*land_helper*" (
    del /f /q "%USERPROFILE%\Desktop\*land_helper*" 2>nul
    for /d %%p in ("%USERPROFILE%\Desktop\*land_helper*") do rmdir /s /q "%%p" 2>nul
)
if exist "%USERPROFILE%\Desktop\*LandHelper*" (
    del /f /q "%USERPROFILE%\Desktop\*LandHelper*" 2>nul
    for /d %%p in ("%USERPROFILE%\Desktop\*LandHelper*") do rmdir /s /q "%%p" 2>nul
)

:: 3. Documents & Temp
del /f /q "%TEMP%\*land_helper*" 2>nul
for /d %%p in ("%TEMP%\*land_helper*") do rmdir /s /q "%%p" 2>nul

echo [2/3] পিসির ক্যাশ ও অপ্রয়োজনীয় টেম্পোরারি ফাইল পরিষ্কার করা হয়েছে।
echo [3/3] সম্পন্ন!
echo.
echo ==============================================================================
echo  ✅ আপনার পিসি থেকে পুরনো সব Land Helper ফাইল স্থায়ীভাবে মুছে ফেলা হয়েছে!
echo.
echo  ⚠️ গুরুত্বপূর্ণ নির্দেশ:
echo  এখন ব্রাউজারে chrome://extensions পেজে গিয়ে যদি পুরনো কোনো Land Helper
echo  এক্সটেনশন থেকে থাকে, সেটির পাশে থাকা "Remove" বাটনে ক্লিক করুন।
echo  এরপর নতুন V2.0 ফোল্ডারটি "Load unpacked" দিয়ে ব্যবহার শুরু করুন।
echo ==============================================================================
echo.
pause
